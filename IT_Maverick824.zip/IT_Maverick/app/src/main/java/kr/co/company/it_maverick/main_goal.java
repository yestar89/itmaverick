package kr.co.company.it_maverick;

public class main_goal {
}
