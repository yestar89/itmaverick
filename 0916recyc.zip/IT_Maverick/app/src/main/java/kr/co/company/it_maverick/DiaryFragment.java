package kr.co.company.it_maverick;

import androidx.fragment.app.Fragment;

public class DiaryFragment extends Fragment {
}
