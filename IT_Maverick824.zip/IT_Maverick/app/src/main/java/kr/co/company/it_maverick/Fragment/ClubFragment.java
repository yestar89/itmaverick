package kr.co.company.it_maverick.Fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toolbar;

import com.google.android.material.tabs.TabLayout;

import kr.co.company.it_maverick.R;


public class ClubFragment extends Fragment {

    private ViewPager viewPager;
    private TabLayout tabLayout;
    private androidx.fragment.app.FragmentManager fragmentManager;


    @Override`
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_club, container, false);
        viewPager = rootView.findViewById(R.id.container);
        tabLayout = rootView.findViewById(R.id.tabs);
        fragmentManager = getChildFragmentManager();

        MyPagerAdapter adapter = new MyPagerAdapter(fragmentManager);
        viewPager.setAdapter(adapter);

        tabLayout.setupWithViewPager(viewPager);

        return rootView;
    }

    private static class MyPagerAdapter extends FragmentPagerAdapter {

        public MyPagerAdapter(FragmentManager fm) {
            super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return new Tab1Fragment(); // 첫 번째 탭의 프래그먼트
                case 1:
                    return new Tab2Fragment(); // 두 번째 탭의 프래그먼트
                case 2:
                    return new Tab3Fragment(); // 세 번째 탭의 프래그먼트
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            return 3; // 총 탭의 개수
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "탭1";
                case 1:
                    return "탭2";
                case 2:
                    return "탭3";
                default:
                    return null;
            }
        }




    }
}