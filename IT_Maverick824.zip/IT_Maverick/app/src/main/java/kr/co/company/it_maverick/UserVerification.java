package kr.co.company.it_maverick;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserVerification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_verification);
    }
}